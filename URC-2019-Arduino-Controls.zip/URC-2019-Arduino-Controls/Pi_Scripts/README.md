#Raspberry pi camera server, will work by using the UV4l Apps
#we will only write here the startup scripts and any config file
#REVISIONS
