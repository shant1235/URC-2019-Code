#include "ros/ros.h"
#include "std_msgs/String.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define BUFSIZE 1024


    int sockfd, portno, n;
    int serverlen;
    struct sockaddr_in serveraddr;
    struct hostent *server;
    const char *hostname;
    char buf[BUFSIZE];


void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  ROS_INFO("I heard: [%s]", msg->data.c_str());





  const char* buf  = msg->data.c_str();
  /* send the message to the server */
  serverlen = sizeof(serveraddr);
//const sockaddr* shut_up = &serveraddr;
  n = sendto(sockfd, buf, strlen(buf), 0,(struct sockaddr *) &serveraddr, serverlen);



}

int main(int argc, char **argv)
{
std::string topic;

  ros::init(argc, argv, "listener");

  ros::NodeHandle n;

  if (n.getParam("sub_topic", topic))
  {
    ROS_INFO("subscriber topic is: %s", topic.c_str());
  }

  ros::Subscriber sub = n.subscribe(topic.c_str(), 1000, chatterCallback);
//udp setup
    std::string s;
    if (n.getParam("host_name", s))
    {
      ROS_INFO("host name is: %s", s.c_str());
    }
    else
    {
      s = "127.0.0.1";
    }
    int i;
    n.param("port_number", i, 8080);
    hostname =s.c_str();// "127.0.0.1";//change ip address later
    portno =i;//atoi(argv[2]); //8080;//change it later


 /* socket: create the socket */
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        ROS_INFO("ERROR opening socket");

    /* gethostbyname: get the server's DNS entry */
    server = gethostbyname(hostname);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host as %s\n", hostname);
        exit(0);
    }

    /* build the server's Internet address */
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)server->h_addr,
	  (char *)&serveraddr.sin_addr.s_addr, server->h_length);
    serveraddr.sin_port = htons(portno);



  ros::spin();

  return 0;
}
