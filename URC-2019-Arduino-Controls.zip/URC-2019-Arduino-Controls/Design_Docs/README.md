This will hold design documents such as the architecture, board layouts, and other communication information
