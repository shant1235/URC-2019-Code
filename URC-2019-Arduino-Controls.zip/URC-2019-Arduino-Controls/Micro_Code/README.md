# URC-2019
#Rover boards 
#Headers should be generalized for the board you are working on
#Include all libraries used in the libraries folder
#Rover_Boards -> Board Name & Type -> Library::Header::INCLUDES::Cfile/ino
#please follow this structure
#
#please put all general scripts such as the udp arduino scripts inside of the
#general Scripts folder
#REVISION LOGS
#
#
#october 30 AY Added folder structure
